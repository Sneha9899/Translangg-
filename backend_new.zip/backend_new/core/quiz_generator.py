import google.generativeai as genai
import json
import time
from functools import wraps


genai.configure(api_key="AIzaSyAL_6FaA_1BeP-NFPhccGZBTPTcaV2_nE8")


def retry(max_retries=3, delay=0, backoff=2):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            delay=0
            retries = 0
            while retries < max_retries:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    print(f"Error: {e}")
                    retries += 1
                    if retries < max_retries:
                        time.sleep(delay)
                        delay *= backoff
            raise Exception(f"Max retries reached for {func.__name__}")

        return wrapper
    return decorator


@retry()
def generate_quiz(content):
    defaults = {
    'model': 'models/text-bison-001',
    'temperature': 0.7,
    'candidate_count': 1,
    'top_k': 40,
    'top_p': 0.95,
    'max_output_tokens': 8000,
    'stop_sequences': [],
    'safety_settings': [{"category":"HARM_CATEGORY_DEROGATORY","threshold":"BLOCK_NONE"},{"category":"HARM_CATEGORY_TOXICITY","threshold":"BLOCK_NONE"},{"category":"HARM_CATEGORY_VIOLENCE","threshold":"BLOCK_NONE"},{"category":"HARM_CATEGORY_SEXUAL","threshold":"BLOCK_NONE"},{"category":"HARM_CATEGORY_MEDICAL","threshold":"BLOCK_NONE"},{"category":"HARM_CATEGORY_DANGEROUS","threshold":"BLOCK_NONE"}],
    }

    prompt = f"""create 5 quiz and 4 options with answer and give it in json format for below data and return only json output

    {content}"""

    response = genai.generate_text(
    **defaults,
    prompt=prompt
    )

    print(response.result)
    quiz = json.loads(response.result[8:-3])
    if isinstance(quiz, list):
        return quiz
    if isinstance(quiz, dict):
        return quiz[list(quiz.keys())[0]]
    raise Exception("unable to parse json from AI")

