
from django.contrib import admin
from django.urls import path
from core.views import get_meida_transcription, get_quiz, login_user, signup_user


urlpatterns = [
    path('transcribe/', get_meida_transcription),
    path('generate-quiz/', get_quiz),
    path('login/', login_user),
    path('signup/', signup_user),
]
