import whisper
from datetime import datetime
import os
import logging
import sys


logging.basicConfig(filename='static\\transcription\\transcription.log', level=logging.INFO)


transcription_output_folder_path = "static\\transcription\\output"

model_type = 'tiny'
model = whisper.load_model(model_type)


def get_transcription(filepath, to_language_code):
    try:
        if 'win' in sys.platform:
            filename = filepath.rsplit('\\',1)[-1]
        else:
            filename = filepath.rsplit('/',1)[-1]


        if not os.path.exists(filepath):
            raise FileNotFoundError(f"file {filename} not found")

        start_time = datetime.now()
        result = model.transcribe(str(filepath), language=to_language_code)
        time_elapsed = datetime.now() - start_time
        
        out_filename = filename.rsplit('.',1)[0] + '.txt'
        out_filepath = os.path.join(transcription_output_folder_path, out_filename)
        
        with open(out_filepath, "w") as f:
            f.write(result['text'])

    except Exception as e:
        logging.error(f"Error {str(e)}: on transcribing file {filepath}")
        raise Exception(str(e))

    logging.info(f"Successfully transcribed file {filepath} - took {time_elapsed}")
    return result.get('text')

