from django.shortcuts import render
from core.constants import LANG_DICT
from django.http import HttpResponse, JsonResponse
from core.transcribe import get_transcription
from core.quiz_generator import generate_quiz
import os
from django.contrib.auth.models import User
# from core.forms import LoginForm


media_folder_path = "static/transcription/media_files"
text_folder_path = "static/transcription/output"

def get_meida_transcription(request):
    try:
        filename = request.GET.get('filename', None)
        if not filename:
            raise ValueError("filename is empty")

        to_lang = request.GET.get('to_lang', None)
        if not to_lang:
            raise ValueError("to language name is empty")

        filepath = os.path.join(media_folder_path, filename)
        if os.path.exists(filepath):
            trascription = get_transcription(filepath, to_lang)
            response_data = {'filename': filename, "trascription": trascription, "success": True}
            return JsonResponse(response_data)
        raise Exception('File not found')

    except Exception as e:
        response_data = {'filename': filename, "trascription": None, "success": False, "error": str(e)}
        return JsonResponse(response_data)


def get_quiz(request):
    try:
        filename = request.GET.get('filename', None)
        if not filename:
            raise ValueError("filename is empty")

        filepath = os.path.join(text_folder_path, filename)

        if os.path.exists(filepath):
            with open(filepath,'r') as ff:
                content = ff.read()
            quiz = generate_quiz(content)
            response_data = {'filename': filename, "quiz": quiz, "success": True}
            return JsonResponse(response_data)
        raise Exception('File not found')

    except Exception as e:
        response_data = {'filename': filename, "quiz": None, "success": False, "error": str(e)}
        return JsonResponse(response_data)

import json

def login_user(request):
    response_data = {'logn': "failed"}
    if request.method == 'POST':
        body_unicode = request.body.decode('utf-8')
        body_data = json.loads(body_unicode)
        # Get the email from the JSON data
        email = body_data.get('email', None)
        password = body_data.get('password', None)

        queryset = User.objects.filter(email=email)
        if queryset:
            user = queryset[0]
            if user.check_password(password):
                response_data = {'logn': "success"}
            else:
                response_data['error'] = 'wrong password'
        else:
            response_data['error'] = 'user not found'

    return JsonResponse(response_data)


def signup_user(request):
    response_data = {'signup': "failed"}
    if request.method == 'POST':
        try:
            body_unicode = request.body.decode('utf-8')
            body_data = json.loads(body_unicode)
            # Get the email from the JSON data
            email = body_data.get('email', None)
            username = body_data.get('username', None)
            password = body_data.get('password', None)

            user = User(email=email, username=username)
            user.set_password(password)
            user.save()
            response_data = {'signup': "success"}
        except Exception:
            pass
    return JsonResponse(response_data)
