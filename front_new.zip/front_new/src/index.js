import React from 'react';
import ReactDOM from 'react-dom';
import {thunk} from 'redux-thunk';
import { BrowserRouter } from 'react-router-dom'
import { ChakraProvider } from '@chakra-ui/react';
import { createRoot, applyMiddleware, compose, createStore } from 'redux';
import { Provider } from 'react-redux';

import reducers from './redux/reducers';
import './index.css';
import App from './App';


const store = createStore(reducers, compose(applyMiddleware(thunk)));
// const root = ReactDOM.createRoot(document.getElementById('root'));
ReactDOM.render(
  <Provider store={store}>
    <React.StrictMode>
      <BrowserRouter>
        <ChakraProvider>
          <App />
        </ChakraProvider>
      </BrowserRouter>
    </React.StrictMode>
  </Provider>,
    document.getElementById('root') 

);

