import React from 'react'

import styles from  './QuizResult.module.css'

function QuizResult(props) {
  return (
    <>
    <div className={styles.showScore}>
        Your Score:{props.score}<br/>
        Total Score:{props.totalScore}
    </div>
    <button className={styles.nextButton} onClick={props.tryAgain}>Try Again</button>
    </>
  )
}

export default QuizResult