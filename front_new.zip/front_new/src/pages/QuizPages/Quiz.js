import React, { useEffect, useState } from 'react'
import { QuizData } from '../QuizData/QuizData'
import QuizResult from './QuizResult';
import { Text } from '@chakra-ui/react'
import { Box, Flex } from "@chakra-ui/react"
import { Button, ButtonGroup } from '@chakra-ui/react'
import { Spinner } from '@chakra-ui/react';

import styles from './QuizPage.module.css'
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';

function Quiz(props) {
    const navigate = useNavigate();
    const QuizQuestions = useSelector((state) => state);
    console.log(112,QuizQuestions.quizReducer.quiz);
    const QuizQuestions_and_Answers = QuizQuestions?.quizReducer?.quiz;
    // QuizQuestions_and_Answers.map((item) => {
    //     // console.log(115,item.question);
    //     console.log(116,item.answer);
    //     // console.log(117,item.options);
    // }); 

    let userInfo = JSON.parse(localStorage.getItem('userInfo'));
    // console.log(userInfo.result.name);
    const [isLoading, setIsLoading] = useState(true);
    const [currentQuestion, setCurrentQuestion] = useState(0);
    const [score, setScore] = useState(0);
    const [clickedOption, setClickedOption] = useState(0);
    const [showResult, setShowResult] = useState(false);

    console.log(117,props.data);

    useEffect(() => {
        if (!localStorage.userInfo) {
            navigate('/');
        }
        if (QuizQuestions.quizReducer.quiz) {
            setIsLoading(false);
        }
    }, [navigate,QuizQuestions.quizReducer.quiz]);



    const matchedAnswer = (answer) => {
        if (!QuizQuestions_and_Answers) {
            return;
        }
        if (QuizQuestions_and_Answers && answer == QuizQuestions_and_Answers[currentQuestion]?.options[0]){
            return 1;
        }else if (QuizQuestions_and_Answers && answer == QuizQuestions_and_Answers[currentQuestion]?.options[1]){
            return 2;
        }
        else if (QuizQuestions_and_Answers && answer == QuizQuestions_and_Answers[currentQuestion]?.options[2]){
            return 3;
        }else if (QuizQuestions_and_Answers && answer == QuizQuestions_and_Answers[currentQuestion]?.options[3]){
            return 4;
        }
        // console.log(149,answer);
        // console.log(150,QuizQuestions_and_Answers[currentQuestion].options[0]);
        // console.log(151,answer === QuizQuestions_and_Answers[currentQuestion].options[0]);
        // console.log(152,answer === QuizQuestions_and_Answers[currentQuestion].options[1]);
        // console.log(153,answer === QuizQuestions_and_Answers[currentQuestion].options[2]);
        // console.log(154,answer === QuizQuestions_and_Answers[currentQuestion].options[3]);

    }

    // console.log(matchedAnswer)

    const changeQuestion = () => {
        updateScore();
        if (currentQuestion < QuizQuestions_and_Answers.length - 1) {
            setCurrentQuestion(currentQuestion + 1);
            setClickedOption(0);
        } else {
            setShowResult(true)
        }
    }
    
    // Checking matched answer value
    // const a = matchedAnswer(QuizQuestions_and_Answers[currentQuestion].answer)
    

    const updateScore = () => {
        if (clickedOption === matchedAnswer(QuizQuestions_and_Answers[currentQuestion]?.answer)) {
            setScore(score + 1);
        }
    }
    const resetAll = () => {
        setShowResult(false);
        setCurrentQuestion(0);
        setClickedOption(0);
        setScore(0);
    }


    const handleLogout = () => {
        localStorage.removeItem('userInfo');
        navigate('/');
    }


    return (
        isLoading ? 
        (
        <center>
            
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh',width:'220vh' }}>
        <Spinner 
            thickness='4px'
            speed='0.65s'
            emptyColor='gray.200'
            color='red.700'
            size='xl'
        />

        </div>
        </center>
        )  :
        

        <div >
                <p className={styles.headingTxt}>Quiz APP</p>
                <center>
            <Text fontSize='4xl' mt={5} ml={500}   color={'tomato'}>Hello {userInfo?.result?.name} </Text>
            <Button colorScheme='red' mt={5} ml={500} onClick={handleLogout} >Logout</Button>
            <Button colorScheme='green' mt={5} ml={5} onClick={() => navigate('/upload')} >Upload Again</Button>
            <br />
            
                </center>
                <div className={styles.container}>
                    {showResult ? (
                        <QuizResult score={score} totalScore={QuizQuestions_and_Answers?.length} tryAgain={resetAll} />
                        ) : (
                            <>
                            <Button style ={ {marginLeft:'20vw'}}colorScheme='blue' type="button" value="Next" onClick={changeQuestion} > Next  </Button>
                            <div className={styles.question}>
                                <span className={styles.questionNumber}> &nbsp; {  currentQuestion + 1}. &nbsp; </span>
                                <span id="question-txt">{QuizQuestions_and_Answers[currentQuestion]?.question}</span>
                            </div>
                            <div className={styles.optionContainer}>
                                {QuizQuestions_and_Answers[currentQuestion].options.map((option, i) => {
                                    return (
                                        <button
                                            className={`${styles.optionBtn} ${clickedOption == i + 1 ? styles.checked : null
                                                }`}
                                            key={i}
                                            onClick={() => setClickedOption(i + 1)}
                                        >
                                            {option}
                                        </button>
                                    )
                                })}
                            </div>

                        </>)}
                        

                </div>
        </div>
    )
}

export default Quiz