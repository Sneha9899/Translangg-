import React, { useEffect, useState } from 'react'
import { Button, ButtonGroup, Toast } from '@chakra-ui/react'
import { useNavigate } from 'react-router-dom'
import { languageNames } from './languages'
import { NavLink } from 'react-router-dom'
import axios from 'axios'
import Quiz from '../QuizPages/Quiz'
import { useDispatch } from 'react-redux'
import { quizAction } from '../../redux/action/QuizData'

// import 'react-languages-select/css/react-languages-select.css';
// import 'react-languages-select/scss/react-languages-select.scss';


const UploadContent = () => {



  // Output the result

  // Output the result
  // console.log(flattenedNames);

  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);
  const [transcription, SetTranscription] = useState(false);
  const [message,setMessage] = useState('');

  const [toLang, setToLang] = useState('');
  const [filename, setFilename] = useState('');


  const navigate = useNavigate();
  const handleUploadAudio = (event) => {
    // handle audio upload
    let filename = event.target.files[0].name;
    console.log(filename)

    setFilename(filename);  };

  const handleUploadVideo = (event) => {
    // handle video upload
    let filename = event.target.files[0].name;
    console.log(filename)
    setFilename(filename);
  };
  const handleToLangChange = (event) => {
    setToLang(event.target.value);
    console.log(event.target.value);
  };

  function changeFileExtension(fileName, newExtension) {
    const dotIndex = fileName.lastIndexOf('.');
  
    if (dotIndex !== -1 && dotIndex > 0) {
      const baseName = fileName.slice(0, dotIndex);
  
      const newFileName = baseName + newExtension;
  
      return newFileName;
    } else {
      return fileName + newExtension;
    }
  }

  const handleGenerateTranscription = async () => {

    if(!filename){
      alert('Please upload a file first');
      return;
    }

    if(!toLang){
      alert('Please select a language first');
      return;
    }

    setLoading(true)
    console.log(62,toLang)
    try {
      const response = await axios.get('http://127.0.0.1:8000/app/transcribe/', {
        params: {
          filename: filename,
          to_lang: toLang,
        },
        // headers: {
        //   'Content-Type': 'application/json',
        // },
      });
  
      console.log(response.data);
      setLoading(false);
      SetTranscription(true);
      setMessage(response.data.trascription);

      // Handle the response as needed
    } catch (error) {
      console.error(error);
      // Handle errors
    }
  };
  

  const handleGenerateQuiz = async() => {

    if(!transcription){
      console.log(transcription)
      alert('Please generate transcription first');
      navigate('/upload'); 
      return;
    }
    try {
      const newExtension = ".txt";

      const newFileName = changeFileExtension(filename, newExtension);

      // const response = await axios.get('http://127.0.0.1:8000/app/generate-quiz/', {
      //   params: {
      //     filename: newFileName,
      //   },
      //   headers: {
      //     'Content-Type': 'application/json',
      //   },
      // });

      // console.log(response.data);
      
      dispatch(quizAction(newFileName));
      // Handle the response as needed
      // <Quiz data={response.data} /> 
      navigate('/dashboard');
    } catch (error) {
      console.error(error);
      // Handle errors
    }
  };

  // const message = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit, a? Nostrum libero unde odit sed ratione earum sequi corporis amet voluptatum sunt. Laudantium enim maxime sint non eos fugiat ratione ad recusandae ipsum magni. Est sapiente unde veniam at iure, illo natus assumenda tempora consequuntur deserunt minima perspiciatis fugiat molestiae?'

  useEffect(() => {
    if (!localStorage.userInfo) {
      navigate('/');
    }
  }, [navigate])

  return (
    <div className='container' style={{
      background: 'rgb(2,0,36)',
      background: 'linear-gradient(51deg, rgba(2,0,36,1) 0%, rgba(122,203,198,1) 13%, rgba(128,193,239,1) 44%, rgba(113,220,131,1) 54%, rgba(0,212,255,1) 72%)',
      overflow: 'auto',
      width: '100vw',
      height: '100vh',
      borderRadius: '4vw'
    }}>
      <center>
        <h2 className='mt-5 text-primary'>Upload Content</h2>
      </center>
      <div className='mt-5 d-flex justify-content-center pt-4'>
        <div>
          <label htmlFor="audio"> <h3 className='text-white'> Upload Audio </h3> </label><br /><br />
          <input className='form-control pr-2' type="file" accept="audio/*" onChange={handleUploadAudio} />
        </div>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <div>
          <label htmlFor="video"> <h3 className='text-white'> Upload Video  </h3> </label> <br /><br />
          <input className='form-control' type="file" accept="video/*" onChange={handleUploadVideo} />
        </div>
      </div>
      {/* Language Selection  */}
      <center>
        <div className='mt-5'>
          <select className='form-control col-md-4' name="" id="" value={toLang} onChange={handleToLangChange}>
            <option value="language">  Select Language  </option>
            {languageNames.map((language) => (
              <option value={language.code}> {language.name} </option>
            ))}
          </select>
        </div>
      </center>

      <Button
              colorScheme='blue'
              width={'40%'}
              style={{ marginLeft: '30vw', marginTop: '4vw' }}
              onClick={handleGenerateTranscription}
              isLoading={loading}
          >Generate Transcription</Button>

      {/* <button className='btn btn-primary ' style={{ marginLeft: '30vw', marginTop: '4vw' }} onClick={handleGenerateTranscription}> Generate Transcription </button> */}
      <p className='text-dark  pt-4'> {transcription && message } </p>


       {/* Quiz Button  */}
           <div className='mt-5' style={{marginLeft:'15vw'}}>
                <button className='btn btn-info' onClick={handleGenerateQuiz}> Generate Quiz </button>
            </div>

    </div>
  )
}

export default UploadContent
