import { Button } from '@chakra-ui/react';
import {Routes,Route} from 'react-router-dom';  

import './App.css';
import ChatPage from './pages/ChatPage';
import HomePage from './pages/HomePage';
import Quiz from './pages/QuizPages/Quiz';
import UploadContent from './pages/page3/UploadContent';
import quizReducer from './redux/reducers/quiz';
// upload audio 
// upload video 
// generate transcription ()



function App() {
  return (
    <div className="App">
      <Routes>
        <Route path='/' element={<HomePage />} exact   />
        {/* <Route path='/chats' element={<ChatPage />}  /> */}
        <Route path='/dashboard' element={<Quiz />}  />
        <Route path='/Upload' element={<UploadContent />}  />
      </Routes>
      {/* <Button colorScheme='blue'>Button</Button> */}
      {/* <h2> Hello </h2> */}
    </div>
  );
}

export default App;
