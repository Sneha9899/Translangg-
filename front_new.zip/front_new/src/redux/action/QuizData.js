import axios from "axios";


export const quizAction = (file) => async (dispatch) => {
        try {
                

                const response = await axios.get('http://127.0.0.1:8000/app/generate-quiz/', {
                        params: {
                            filename: file,
                        },
                        headers: {
                            'Content-Type': 'application/json',
                        },
                });

                // Dispatch an action with the response data
                dispatch({ type: 'QUIZ_DATA', payload: response.data });
                console.log("This is from QuizData action ",response.data);

        } catch(error) {
                console.log(error.message)
        }
}