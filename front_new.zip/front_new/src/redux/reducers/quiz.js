const quizReducer = (state = {data:null},action) => {
    switch(action.type){
        case 'QUIZ_DATA':
            return action.payload;
        default:
            return state;
    }
}
export default quizReducer;